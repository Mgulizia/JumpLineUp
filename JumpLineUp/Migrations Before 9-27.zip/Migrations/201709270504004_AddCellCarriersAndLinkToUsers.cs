namespace JumpLineUp.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddCellCarriersAndLinkToUsers : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.CellularCarriers",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        CarrierName = c.String(),
                        CarrierExtension = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            AddColumn("dbo.AspNetUsers", "Phone", c => c.String(nullable: false));
            AddColumn("dbo.AspNetUsers", "CellularCarriersId", c => c.Int(nullable: false));
            CreateIndex("dbo.AspNetUsers", "CellularCarriersId");
            AddForeignKey("dbo.AspNetUsers", "CellularCarriersId", "dbo.CellularCarriers", "Id", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.AspNetUsers", "CellularCarriersId", "dbo.CellularCarriers");
            DropIndex("dbo.AspNetUsers", new[] { "CellularCarriersId" });
            DropColumn("dbo.AspNetUsers", "CellularCarriersId");
            DropColumn("dbo.AspNetUsers", "Phone");
            DropTable("dbo.CellularCarriers");
        }
    }
}
